package com.develou.lawyersapp.data;

import android.provider.BaseColumns;

/**
 * Esquema de la base de datos para abogados
 */
public class VideojContract {

    public static abstract class VideojEntry implements BaseColumns{
        public static final String TABLE_NAME ="lawyer";

        public static final String ID = "id";
        public static final String NOMBRE = "nombre";
        public static final String GENERO = "genero";
        public static final String PRECIO = "precio";
        public static final String AVATAR_URI = "avatarUri";
        public static final String DESC = "descripcion";
    }
}
