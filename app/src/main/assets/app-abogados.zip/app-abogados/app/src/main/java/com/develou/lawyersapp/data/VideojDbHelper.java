package com.develou.lawyersapp.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static com.develou.lawyersapp.data.VideojContract.VideojEntry;

/**
 * Manejador de la base de datos
 */
public class VideojDbHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "videojuegos.db";

    public VideojDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + VideojEntry.TABLE_NAME + " ("
                + VideojEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + VideojEntry.ID + " TEXT NOT NULL,"
                + VideojEntry.NOMBRE + " TEXT NOT NULL,"
                + VideojEntry.GENERO + " TEXT NOT NULL,"
                + VideojEntry.PRECIO + " TEXT NOT NULL,"
                + VideojEntry.DESC + " TEXT NOT NULL,"
               + VideojEntry.AVATAR_URI + " TEXT,"
                + "UNIQUE (" + VideojEntry.ID + "))");



        // Insertar datos ficticios para prueba inicial
        mockData(db);

    }

    private void mockData(SQLiteDatabase sqLiteDatabase) {
        mockLawyer(sqLiteDatabase, new Videoj("GTA5", "Accion",
                "59.95", "Grand Theft Auto V es un juego de acción y aventuras de 2013" +
                " desarrollado por Rockstar North y publicado por Rockstar Games." +
                " Es la séptima entrada principal en la serie Grand Theft Auto, después de Grand Theft Auto IV de 2008, " +
                "y la decimoquinta entrega en general",
                "gta.jpg"));
        mockLawyer(sqLiteDatabase, new Videoj("FIFA 23", "Deportes",
                "69.99", "FIFA 23 es un videojuego de simulación de fútbol publicado por Electronic Arts. Es la trigésima entrega de la serie " +
                "FIFA desarrollada por EA Sports, y la última entrega bajo el estandarte de FIFA.",
                "fifa.jpg"));

    }

    public long mockLawyer(SQLiteDatabase db, Videoj videoj) {
        return db.insert(
                VideojContract.VideojEntry.TABLE_NAME,
                null,
                videoj.toContentValues());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // No hay operaciones
    }

    public long saveVid(Videoj vid) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        return sqLiteDatabase.insert(
                VideojEntry.TABLE_NAME,
                null,
                vid.toContentValues());

    }

    public Cursor getAllVid() {
        return getReadableDatabase()
                .query(
                        VideojEntry.TABLE_NAME,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null);
    }

    public Cursor getVideojById(String lawyerId) {
        Cursor c = getReadableDatabase().query(
                VideojEntry.TABLE_NAME,
                null,
                VideojEntry.ID + " LIKE ?",
                new String[]{lawyerId},
                null,
                null,
                null);
        return c;
    }

    public int deleteVid(String vidjId) {
        return getWritableDatabase().delete(
                VideojEntry.TABLE_NAME,
                VideojEntry.ID + " LIKE ?",
                new String[]{vidjId});
    }

    public int updateVideoj(Videoj vid, String vidId) {
        return getWritableDatabase().update(
                VideojEntry.TABLE_NAME,
                vid.toContentValues(),
                VideojEntry.ID + " LIKE ?",
                new String[]{vidId}
        );
    }
}
