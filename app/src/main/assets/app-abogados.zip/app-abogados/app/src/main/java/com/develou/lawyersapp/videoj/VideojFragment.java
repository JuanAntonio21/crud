package com.develou.lawyersapp.videoj;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.develou.lawyersapp.R;
import com.develou.lawyersapp.addeditvideoj.AddEditVideojActivity;
import com.develou.lawyersapp.data.VideojDbHelper;
import com.develou.lawyersapp.videojdetail.VideojDetailActivity;

import static com.develou.lawyersapp.data.VideojContract.VideojEntry;


/**
 * Vista para la lista de abogados del gabinete
 */
public class VideojFragment extends Fragment {
    public static final int REQUEST_UPDATE_DELETE_GAME = 2;

    private VideojDbHelper ayuda;

    private ListView lista;
    private VideojCursorAdapter adapter;
    private FloatingActionButton añadirB;


    public VideojFragment() {
        // Required empty public constructor
    }

    public static VideojFragment newInstance() {
        return new VideojFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_videoj, container, false);

        // Referencias UI
        lista = (ListView) root.findViewById(R.id.lawyers_list);
        adapter = new VideojCursorAdapter(getActivity(), null);
        añadirB = (FloatingActionButton) getActivity().findViewById(R.id.fab);

        // Setup
        lista.setAdapter(adapter);

        // Eventos
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Cursor currentItem = (Cursor) adapter.getItem(i);
                String currentLawyerId = currentItem.getString(
                        currentItem.getColumnIndex(VideojEntry.ID));

                showDetailScreen(currentLawyerId);
            }
        });
        añadirB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddScreen();
            }
        });


        getActivity().deleteDatabase(VideojDbHelper.DATABASE_NAME);

        // Instancia de helper
        ayuda = new VideojDbHelper(getActivity());

        // Carga de datos
        loadLawyers();

        return root;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Activity.RESULT_OK == resultCode) {
            switch (requestCode) {
                case AddEditVideojActivity.REQUEST_ADD_VIDEOJ:
                    showSuccessfullSavedMessage();
                    loadLawyers();
                    break;
                case REQUEST_UPDATE_DELETE_GAME:
                    loadLawyers();
                    break;
            }
        }
    }

    private void loadLawyers() {
        new LawyersLoadTask().execute();
    }

    private void showSuccessfullSavedMessage() {
        Toast.makeText(getActivity(),
                "Videojuego guardado correctamente", Toast.LENGTH_SHORT).show();
    }

    private void showAddScreen() {
        Intent intent = new Intent(getActivity(), AddEditVideojActivity.class);
        startActivityForResult(intent, AddEditVideojActivity.REQUEST_ADD_VIDEOJ);
    }

    private void showDetailScreen(String lawyerId) {
        Intent intent = new Intent(getActivity(), VideojDetailActivity.class);
        intent.putExtra(VideojActivity.EXTRA_VIDEOJ_ID, lawyerId);
        startActivityForResult(intent, REQUEST_UPDATE_DELETE_GAME);
    }

    private class LawyersLoadTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return ayuda.getAllVid();
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            if (cursor != null && cursor.getCount() > 0) {
                adapter.swapCursor(cursor);
            } else {
                // Mostrar empty state
            }
        }
    }

}
